#!/bin/bash

echo "[+] Starting nginx RTMP server..."
sudo /usr/local/nginx/sbin/nginx

echo "[+] Starting FFmpeg segmenter..."
ffmpeg -r 25 -i rtmp://localhost/live/test123 \
  -c:v libx264 -preset ultrafast -tune zerolatency \
  -g 25 -keyint_min 25 -sc_threshold 0 \
  -force_key_frames "expr:gte(t,n_forced*1)" \
  -c:a aac \
  -f segment -segment_time 1 -reset_timestamps 1 -strftime 1 \
  /home/ubuntu/clips/segment-%Y%m%d-%H%M%S.ts \
  > /dev/null 2>&1 &

ffmpeg   -stream_loop -1   -re   -i /home/ubuntu/TestFileSend/garage.gif   -vf "scale=640:-2,fps=25"   -c:v libx264   -preset ultrafast   -pix_fmt yuv420p   -g 50   -f flv rtmp://ubuntudoorbell.duckdns.org/live/testgif > /dev/null 2>&1 &

echo "[+] Starting Flask web server with Gunicorn..."
cd /home/ubuntu/TestFileSend

gunicorn webServer:app \
  --bind 0.0.0.0:5000 \
  --workers 4 \
  --threads 8 \
  --timeout 180 \
  > /dev/null 2>&1 &

echo "[+] Starting motion detection worker..."
python3 motion-worker.py > /dev/null 2>&1 &
echo "[✓] Doorbell system started."

