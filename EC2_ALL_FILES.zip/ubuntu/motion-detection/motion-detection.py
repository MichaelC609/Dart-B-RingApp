import cv2
import numpy as np
import requests
import signal
import time
import sys
import json
from google.auth.transport.requests import Request
from google.oauth2 import service_account

# ==== CONFIG ====
RTMP_STREAM_URL = "rtmp://ubuntudoorbell.duckdns.org/live/test123"
FCM_DEVICE_TOKEN = "fhziIXh7TgmzKNgVgQW5JM:APA91bGWX9Zup3Q-E85CXne-ttL4BwlBfBGPb4qbaiJ4vzK9sscinoZUOnwYw0bw5YzG4RnQQ3ccH2yf1uEysmMkIf9QGgG_JVm0vcG3AbCAaMByoSkflBw"
FIREBASE_CREDENTIALS_FILE = "firebase_credentials.json"
NOTIFY_INTERVAL = 10  # seconds
MOTION_AREA_THRESHOLD = 400
FRAME_SKIP = 5        # process 1 in every 5 frames
# ================

# Load service account credentials
with open(FIREBASE_CREDENTIALS_FILE, "r") as f:
    SERVICE_ACCOUNT_INFO = json.load(f)

KERNEL = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))
running = True

def shutdown_handler(sig, frame):
    global running
    print("\nShutting down...")
    running = False

signal.signal(signal.SIGINT, shutdown_handler)

def get_access_token():
    credentials = service_account.Credentials.from_service_account_info(
        SERVICE_ACCOUNT_INFO,
        scopes=["https://www.googleapis.com/auth/firebase.messaging"]
    )
    credentials.refresh(Request())
    return credentials.token

def send_notification():
    try:
        access_token = get_access_token()
        project_id = SERVICE_ACCOUNT_INFO["project_id"]

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json; UTF-8",
        }

        message = {
            "message": {
                "token": FCM_DEVICE_TOKEN,
                "notification": {
                    "title": "📹 Motion Detected",
                    "body": "Movement was detected on your doorbell camera."
                },
                "data": {
                    "source": "motion-detector",
                    "type": "motion"
                }
            }
        }

        url = f"https://fcm.googleapis.com/v1/projects/{project_id}/messages:send"
        response = requests.post(url, headers=headers, json=message)
        print("Notification sent:", response.status_code, response.text)

    except Exception as e:
        print("Error sending notification:", e)

def get_mask(frame1, frame2):
    frame_diff = cv2.absdiff(frame2, frame1)
    frame_diff = cv2.medianBlur(frame_diff, 3)
    mask = cv2.adaptiveThreshold(frame_diff, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                 cv2.THRESH_BINARY_INV, 11, 3)
    mask = cv2.medianBlur(mask, 3)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, KERNEL, iterations=1)
    return mask

def get_contour_detections(mask, thresh=MOTION_AREA_THRESHOLD):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)
    detections = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        area = w * h
        if area > thresh:
            detections.append([x, y, x + w, y + h, area])
    return np.array(detections)

def main():
    global running
    print("Starting motion detection. Press Ctrl+C to stop.")
    prev_gray = None
    last_notify_time = 0
    frame_count = 0

    while running:
        cap = cv2.VideoCapture(RTMP_STREAM_URL)
        if not cap.isOpened():
            print("Failed to open RTMP stream. Retrying in 5 seconds...")
            time.sleep(5)
            continue

        while running:
            ret, frame = cap.read()
            if not ret:
                print("Frame read failed. Attempting to reconnect...")
                break  # Will reopen cap in outer loop

            frame_count += 1
            if frame_count % FRAME_SKIP != 0:
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            if prev_gray is not None:
                mask = get_mask(prev_gray, gray)
                detections = get_contour_detections(mask)

                if len(detections) > 0:
                    now = time.time()
                    if now - last_notify_time > NOTIFY_INTERVAL:
                        print(f"[{time.strftime('%X')}] Motion detected!")
                        send_notification()
                        last_notify_time = now

            prev_gray = gray

        cap.release()
        print("Reconnecting to stream...")

    print("Motion detection stopped.")

if __name__ == "__main__":
    main()

