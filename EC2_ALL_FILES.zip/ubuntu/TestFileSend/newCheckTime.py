import os
def checkTime(path):
    return len(os.listdir(path))
print(checkTime("/home/ubuntu/clips"))
