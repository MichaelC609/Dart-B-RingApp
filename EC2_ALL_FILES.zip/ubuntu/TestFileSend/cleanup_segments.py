import os

# Assumption: 1 .ts file = 1 second
MAX_BUFFER_SECONDS = 660  # max buffer size in seconds
CLIP_PATH = "/home/ubuntu/clips"

# Function to "check time" by counting the number of .ts files
def checkTime(path):
    return len(os.listdir(path))

# Function to delete the N oldest .ts files
def delete_oldest_files(path, count):
    files = [os.path.join(path, f) for f in os.listdir(path)]
    if not files:
        print("No .ts files to delete.")
        return
    # Sort files by creation time (oldest first)
    oldest_files = sorted(files, key=os.path.getctime)[:count]
    for f in oldest_files:
        try:
            os.remove(f)
            print(f"Deleted: {f}")
        except Exception as e:
            print(f"Error deleting {f}: {e}")

# Main logic
def main():
    path = CLIP_PATH
    while checkTime(path) > MAX_BUFFER_SECONDS:
        excess = checkTime(path) - MAX_BUFFER_SECONDS
        delete_oldest_files(path, count=excess)

if __name__ == "__main__":
    main()
