import os
import time
import subprocess
import json

def get_duration_ffprobe(filepath):
    try:
        result = subprocess.run(
            [
                "ffprobe", "-v", "error",
                "-show_entries", "format=duration",
                "-of", "json", filepath
            ],
            capture_output=True,
            text=True
        )
        output = json.loads(result.stdout)
        return float(output["format"]["duration"])
    except Exception as e:
        print(f"Error with {filepath}: {e}")
        return 0.0


# Function to check total video time across .ts files
def checkTime(path):
    total_seconds = 0.0
    for f in os.listdir(path):
        full_path = os.path.join(path, f)
        total_seconds += get_duration_ffprobe(full_path)
    return total_seconds
print("Length of clips combined:")
print(checkTime("/home/ubuntu/clips/"))
