from flask import (
    Flask,
    send_file,
    request,
    after_this_request,
    jsonify,
    send_from_directory,
)
import os, time, subprocess
import cv2
import numpy as np
import requests
import signal
import sys
import json
from google.auth.transport.requests import Request
from google.oauth2 import service_account
import sqlite3
from threading import Thread
import zipfile

app = Flask(__name__)

# ==== CONFIG ====
RTMP_STREAM_URL = "rtmp://ubuntudoorbell.duckdns.org/live/test123"
FCM_DEVICE_TOKEN = "fhziIXh7TgmzKNgVgQW5JM:APA91bGWX9Zup3Q-E85CXne-ttL4BwlBfBGPb4qbaiJ4vzK9sscinoZUOnwYw0bw5YzG4RnQQ3ccH2yf1uEysmMkIf9QGgG_JVm0vcG3AbCAaMByoSkflBw"
FIREBASE_CREDENTIALS_FILE = "firebase_credentials.json"
NOTIFY_INTERVAL = 10  # seconds
MOTION_AREA_THRESHOLD = 400
FRAME_SKIP = 5  # process 1 in every 5 frames
# ================

# Load service account credentials
with open(FIREBASE_CREDENTIALS_FILE, "r") as f:
    SERVICE_ACCOUNT_INFO = json.load(f)

KERNEL = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))
running = True


def shutdown_handler(sig, frame):
    global running
    print("\nShutting down...")
    running = False
    sys.exit(0)


signal.signal(signal.SIGINT, shutdown_handler)

SNAPSHOT_FOLDER = "./motion_snapshots"
os.makedirs(SNAPSHOT_FOLDER, exist_ok=True)

DB_PATH = "./motion_logs.db"


@app.route("/sample.py")
def snapshot():
    return send_file("/home/ubuntu/TestFileSend/sample.py", mimetype="text/plain")

@app.route("/get_logs", methods=["GET"])
def get_logs():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM logs ORDER BY timestamp DESC")
    logs = [
        {"id": row[0], "timestamp": row[1], "description": row[2], "photo_path": row[3]}
        for row in c.fetchall()
    ]
    conn.close()
    return jsonify(logs)


@app.route("/clear_logs", methods=["POST"])
def clear_logs():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM logs")
    conn.commit()
    conn.close()
    return jsonify({"status": "cleared"})


@app.route("/log_button_press", methods=["POST"])
def log_button_press():
    data = request.get_json(silent=True) or {}
    photo_path = data.get("photo_path", None)  # Optional
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    description = "Button pressed"

    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute(
            "INSERT INTO logs (timestamp, description, photo_path) VALUES (?, ?, ?)",
            (timestamp, description, photo_path),
        )
        conn.commit()
        conn.close()
        print(f"Button press event logged: {timestamp}, {photo_path}")
        return jsonify({"status": "success", "timestamp": timestamp}), 200
    except Exception as e:
        print("Error logging button press:", e)
        return jsonify({"status": "error", "message": str(e)}), 500



@app.route("/delete_logs", methods=["POST"])
def delete_logs():
    data = request.get_json()
    ids = data.get("ids", [])
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.executemany("DELETE FROM logs WHERE id = ?", [(log_id,) for log_id in ids])
    conn.commit()
    conn.close()
    return jsonify({"deleted": len(ids)})


@app.route("/motion_snapshots/<filename>")
def get_snapshot(filename):
    return send_from_directory("motion_snapshots", filename)


@app.route('/clip')
def clip():
    seconds = int(request.args.get('seconds', 60))
    path = '/home/ubuntu/clips/'

    # Get segment files (oldest to newest)
    files = sorted([f for f in os.listdir(path) if f.endswith('.ts')])
    files_to_clip = files[-seconds:] if len(files) >= seconds else files

    valid_files = []
    for name in files_to_clip:
        full_path = os.path.join(path, name)
        if os.path.exists(full_path):
            valid_files.append(full_path)

    if not valid_files:
        return "No footage available yet", 404

    timestamp = time.strftime('%Y%m%d-%H%M%S')
    list_file = f'/tmp/ts_list_{timestamp}.txt'
    combined_output = f'/tmp/combined_{timestamp}.mp4'
    trimmed_output = f'/tmp/clip_{timestamp}.mp4'
    zip_output = f'/tmp/clip_{timestamp}.zip'

    # Create the list file for FFmpeg concat
    with open(list_file, 'w') as f:
        for full_path in valid_files:
            f.write(f"file '{full_path}'\n")

    # Step 1: Concatenate
    subprocess.run([
        'ffmpeg', '-y', '-f', 'concat', '-safe', '0',
        '-i', list_file, '-c', 'copy', combined_output
    ])

    # Step 2: Trim
    subprocess.run([
        'ffmpeg', '-y', '-sseof', f'-{seconds}', '-i', combined_output,
        '-c', 'copy', trimmed_output
    ])

    # Step 3: Optionally zip it
    if seconds > 10:
        with zipfile.ZipFile(zip_output, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(trimmed_output, arcname=os.path.basename(trimmed_output))

    # Cleanup
    @after_this_request
    def cleanup(response):
        for f in [combined_output, trimmed_output, list_file, zip_output]:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except Exception as e:
                print(f"Error deleting {f}: {e}")
        return response

    if seconds > 10:
        return send_file(zip_output, mimetype='application/zip', as_attachment=True, download_name=f'{timestamp}.zip')
    else:
        return send_file(trimmed_output, mimetype='video/mp4', as_attachment=True, download_name=f'{timestamp}.mp4')


def main():
    global running
    print("Starting motion detection. Press Ctrl+C to stop.")
    prev_gray = None
    last_notify_time = 0
    frame_count = 0

    while running:
        cap = cv2.VideoCapture(RTMP_STREAM_URL)
        if not cap.isOpened():
            print("Failed to open RTMP stream. Retrying in 5 seconds...")
            time.sleep(5)
            continue

        while running:
            ret, frame = cap.read()
            if not ret:
                print("Frame read failed. Attempting to reconnect...")
                break  # Will reopen cap in outer loop

            frame_count += 1
            if frame_count % FRAME_SKIP != 0:
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            if prev_gray is not None:
                mask = get_mask(prev_gray, gray)
                detections = get_contour_detections(mask)

                if len(detections) > 0:
                    now = time.time()
                    if now - last_notify_time > NOTIFY_INTERVAL:
                        print(f"[{time.strftime('%X')}] Motion detected!")
                        snapshot_path = save_snapshot(frame)  # Save the snapshot
                        log_motion_event(snapshot_path)
                        send_notification()
                        last_notify_time = now

            prev_gray = gray

        cap.release()
        print("Reconnecting to stream...")

    print("Motion detection stopped.")


def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            description TEXT NOT NULL,
            photo_path TEXT
        )
    """
    )
    conn.commit()
    conn.close()


def log_motion_event(photo_path):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    description = "Motion detected"
    c.execute(
        "INSERT INTO logs (timestamp, description, photo_path) VALUES (?, ?, ?)",
        (timestamp, description, photo_path),
    )
    conn.commit()
    conn.close()
    print(f"Motion event logged: {timestamp}, {photo_path}")


def save_snapshot(frame):
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    snapshot_path = os.path.join(SNAPSHOT_FOLDER, f"motion_{timestamp}.jpg")
    cv2.imwrite(snapshot_path, frame)
    print(f"Snapshot saved: {snapshot_path}")
    return snapshot_path


def get_access_token():
    credentials = service_account.Credentials.from_service_account_info(
        SERVICE_ACCOUNT_INFO,
        scopes=["https://www.googleapis.com/auth/firebase.messaging"],
    )
    credentials.refresh(Request())
    return credentials.token


def send_notification():
    try:
        access_token = get_access_token()
        project_id = SERVICE_ACCOUNT_INFO["project_id"]

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json; UTF-8",
        }

        message = {
            "message": {
                "token": FCM_DEVICE_TOKEN,
                "notification": {
                    "title": "📹 Motion Detected",
                    "body": "Movement was detected on your doorbell camera.",
                },
                "data": {"source": "motion-detector", "type": "motion"},
            }
        }

        url = f"https://fcm.googleapis.com/v1/projects/{project_id}/messages:send"
        response = requests.post(url, headers=headers, json=message)
        print("Notification sent:", response.status_code, response.text)

    except Exception as e:
        print("Error sending notification:", e)


def get_mask(frame1, frame2):
    frame_diff = cv2.absdiff(frame2, frame1)
    frame_diff = cv2.medianBlur(frame_diff, 3)
    mask = cv2.adaptiveThreshold(
        frame_diff, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 3
    )
    mask = cv2.medianBlur(mask, 3)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, KERNEL, iterations=1)
    return mask


def get_contour_detections(mask, thresh=MOTION_AREA_THRESHOLD):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)
    detections = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        area = w * h
        if area > thresh:
            detections.append([x, y, x + w, y + h, area])
    return np.array(detections)


def is_glitch(diff_frame, threshold=25, ratio_thresh=0.25):
    """Returns True if a frame is likely a glitch due to high global change."""
    num_diff_pixels = np.sum(diff_frame > threshold)
    total_pixels = diff_frame.size
    ratio = num_diff_pixels / total_pixels
    return ratio > ratio_thresh
