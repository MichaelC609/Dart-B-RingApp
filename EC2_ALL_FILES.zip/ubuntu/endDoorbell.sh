#!/bin/bash

echo "[+] Stopping nginx..."
sudo /usr/local/nginx/sbin/nginx -s stop

echo "[+] Killing FFmpeg segmenter..."
pkill -f "ffmpeg -r 25 -i rtmp://localhost/live/test123"

echo "[+] Killing Gunicorn web server..."
pkill -f "gunicorn webServer:app"

echo "[+] Killing motion detection worker..."
pkill -f "motion-worker.py"

echo "[✓] Doorbell system stopped."

